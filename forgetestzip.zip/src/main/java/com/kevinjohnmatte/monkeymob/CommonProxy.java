package com.kevinjohnmatte.monkeymob;

import net.minecraft.item.ItemFood;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class CommonProxy
{	
	public void preInit(FMLPreInitializationEvent e) 
	{
		
	}

	public void init(FMLInitializationEvent e) 
	{
		Main.banana = new ItemFood(3, 0.3F, false);
		Main.banana.setUnlocalizedName("banana");
		GameRegistry.registerItem(Main.banana, "banana");
		
		Main.bananaplant = new BlockBananaPlantRoot(Main.banana, 3, 1, 5, 2, 2, 12, 10, 30, 40, 100, 5, 10, 3, 1, null);
	}

	public void postInit(FMLPostInitializationEvent e) 
	{
		
	}
}
